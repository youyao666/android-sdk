# Android SDK/NDK 工具调用指南 (Windows环境)

本文档总结了在Windows环境下正确调用Android SDK/NDK工具的方法，特别是处理包含空格的路径。

## 问题背景

在Windows环境下，当Android NDK路径包含空格时，直接调用NDK工具可能会出现问题。这是因为Windows的命令行解释器在处理包含空格的路径时需要特殊处理。

## 解决方案

### 1. 使用批处理脚本 (.bat)

批处理脚本是处理包含空格路径的最可靠方式。在脚本中，使用双引号包围路径，并直接调用工具。

示例:
```batch
@echo off
set ANDROID_NDK_ROOT=F:\github ai\android-ndk-r27d-windows\android-ndk-r27d
"%ANDROID_NDK_ROOT%\prebuilt\windows-x86_64\bin\make.exe" --version
```

### 2. 使用PowerShell脚本 (.ps1)

PowerShell脚本也可以处理包含空格的路径，但需要注意编码问题。在脚本中，使用`&`调用操作符和双引号包围路径。

示例:
```powershell
$ANDROID_NDK_ROOT = "F:\github ai\android-ndk-r27d-windows\android-ndk-r27d"
& "$ANDROID_NDK_ROOT\prebuilt\windows-x86_64\bin\make.exe" --version
```

运行PowerShell脚本时，使用以下命令:
```cmd
powershell -ExecutionPolicy Bypass -File "path\to\script.ps1"
```

### 3. 直接在命令行中调用

在命令行中直接调用时，确保使用双引号包围包含空格的路径。

示例:
```cmd
"F:\github ai\android-ndk-r27d-windows\android-ndk-r27d\prebuilt\windows-x86_64\bin\make.exe" --version
```

## 注意事项

1. 在批处理脚本中，使用`%variable%`引用变量。
2. 在PowerShell脚本中，使用`$variable`引用变量，并使用`&`调用操作符执行命令。
3. 确保脚本文件使用正确的编码格式（推荐UTF-8）。
4. 在运行PowerShell脚本之前，可能需要更改执行策略：`Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope CurrentUser`

## 项目文件说明

- `sdk_launcher.bat`: 批处理版本的SDK/NDK工具启动器（简化版，专注于编译Android程序）
- `sdk_launcher.ps1`: PowerShell版本的SDK/NDK工具启动器