#include <stdio.h>

int main() {
    printf("Hello, Android NDK!\n");
    return 0;
}