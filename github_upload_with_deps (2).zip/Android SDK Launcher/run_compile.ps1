Set-Location -Path "F:\github ai\Android SDK Launcher"
Start-Process -FilePath "compile_with_clang.bat" -Wait