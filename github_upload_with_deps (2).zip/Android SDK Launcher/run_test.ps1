Set-Location -Path "F:\github ai\Android SDK Launcher"
Start-Process -FilePath ".\test_clang.exe" -NoNewWindow -Wait