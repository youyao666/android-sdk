#include <stdio.h>

int main() {
    printf("Hello, Clang!\n");
    return 0;
}