﻿# Android NDK Hello World 编译脚本 (PowerShell)
# 处理包含空格的路径

# 设置NDK根目录路径
 = " F:\github ai\android-ndk-r27d-windows\android-ndk-r27d\

# 检查路径是否存在
if (-not (Test-Path )) {
 Write-Error \NDK路径不存在: \
 exit 1
}

# 设置编译器路径
 = \\toolchains\llvm\prebuilt\windows-x86_64\bin\aarch64-linux-android21-clang.cmd\

# 检查编译器是否存在
if (-not (Test-Path )) {
 Write-Error \编译器不存在: \
 exit 1
}

# 编译hello.c
Write-Host \开始编译 hello.c...\
& \\ -o hello.exe hello.c

# 检查编译结果
if (1 -eq 0) {
 Write-Host \\ 
 Write-Host \========================================\ -ForegroundColor Green
 Write-Host \编译成功！\ -ForegroundColor Green
 Write-Host \========================================\ -ForegroundColor Green
 
 # 显示生成的文件信息
 if (Test-Path \hello.exe\) {
 Write-Host \文件信息:\
 Get-Item \hello.exe\ | Select-Object Name, Length, LastWriteTime
 } else {
 Write-Warning \编译成功但未找到输出文件\
 }
} else {
 Write-Host \\ 
 Write-Host \========================================\ -ForegroundColor Red
 Write-Host \编译失败！\ -ForegroundColor Red
 Write-Host \========================================\ -ForegroundColor Red
 exit 1
}

Write-Host \\ 
Write-Host \脚本执行完成。\
