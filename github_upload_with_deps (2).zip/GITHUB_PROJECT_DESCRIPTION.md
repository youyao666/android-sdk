# GitHub 项目介绍

## 项目概述

本项目是一个Android NDK Hello World示例，演示了如何使用Android NDK编译一个简单的C程序。项目旨在解决在Windows环境下调用Android NDK工具时遇到的路径包含空格的问题，并提供多种解决方案和最佳实践。

## 项目作用

1. **学习NDK开发**：为初学者提供一个简单的NDK开发示例，帮助理解NDK的基本使用方法。
2. **解决路径问题**：提供在Windows环境下处理包含空格的NDK路径的解决方案。
3. **构建脚本示例**：包含多种构建脚本（.bat和.ps1），展示不同的构建方式。
4. **SDK调用演示**：通过`sdk_launcher.bat`和`sdk_launcher.ps1`演示如何调用NDK工具。
5. **跨平台编译**：演示如何在Windows平台上编译生成Android ARM64架构的可执行文件。
6. **工具链验证**：验证Android NDK工具链的正确配置，包括make.exe、ndk-build.cmd等工具。

## 项目缺点

1. **功能简单**：项目仅包含一个简单的"Hello World"程序，功能较为基础，不适合作为复杂项目开发的参考。
2. **平台限制**：当前构建脚本主要针对Windows平台，缺乏对Linux或macOS平台的支持。
3. **架构局限**：项目仅针对ARM64架构进行编译，未提供对其他架构（如x86、ARM32）的支持。
4. **API级别固定**：项目使用固定的Android API级别21，未展示如何针对不同API级别进行开发。
5. **缺少测试**：项目缺乏完整的测试用例，无法验证在不同Android设备上的兼容性。
6. **文档不全**：虽然包含基本的README文件，但缺少详细的API文档和开发指南。

## 项目结构

- `hello.c` - 源代码文件
- `reliable_build.bat` - Windows平台下的编译脚本
- `package_app.bat` - Windows平台下的打包脚本
- `build_and_package.bat` - Windows平台下的一键构建和打包脚本
- `Android SDK Launcher` - 包含SDK启动脚本和相关文件的目录
- `Makefile` - 用于编译C程序的Makefile
- `PROJECT_SUMMARY.md` - 项目总结文档

## 编译和运行

项目提供了多种编译和运行方式：

1. **分步执行**：分别运行`reliable_build.bat`和`package_app.bat`脚本。
2. **一键执行**：运行`build_and_package.bat`脚本完成编译和打包。
3. **使用SDK启动器**：通过`Android SDK Launcher`目录中的`sdk_launcher.bat`脚本运行程序。

## 技术细节

- 使用Android NDK r27d版本中的clang编译器
- 目标架构：ARM64 (aarch64)
- Android API级别：21
- 提供处理包含空格路径的最佳实践