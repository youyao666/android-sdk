# Android NDK Hello World 示例

这个项目演示了如何使用Android NDK编译一个简单的C程序。

## 项目结构

- `hello.c` - 源代码文件
- `reliable_build.bat` - Windows平台下的编译脚本
- `package_app.bat` - Windows平台下的打包脚本
- `build_and_package.bat` - Windows平台下的一键构建和打包脚本
- `android-ndk-r27d-windows` - Android NDK工具链

## 编译和打包方法

### 方法1：分步执行

1. 编译：双击运行`reliable_build.bat`脚本，或者在命令行中执行：

```
cmd /c "reliable_build.bat"
```

2. 打包：双击运行`package_app.bat`脚本，或者在命令行中执行：

```
cmd /c "package_app.bat"
```

### 方法2：一键执行

双击运行`build_and_package.bat`脚本，或者在命令行中执行：

```
cmd /c "build_and_package.bat"
```

编译成功后会生成`hello`文件（没有扩展名），这是一个可以在Android设备上运行的ARM64可执行文件。

## 运行程序

编译和打包完成后，所有必要的文件都会被放置在`Android SDK Launcher`目录中：

- `hello` - 编译生成的可执行文件
- `hello.c` - 源代码文件
- `sdk_launcher.bat` - SDK启动脚本

要运行程序，只需双击`Android SDK Launcher`目录中的`sdk_launcher.bat`脚本，或者在命令行中执行：

```
cd "Android SDK Launcher"
sdk_launcher.bat
```

程序将在控制台中输出"Hello, Android NDK!"并等待用户按键退出。这为其他AI提供了一个明确的SDK入口点，可以直接调用此脚本来使用SDK功能。

## 代码说明

源代码非常简单，只包含一个打印语句：

```c
#include <stdio.h>

int main() {
    printf("Hello, Android NDK!\n");
    return 0;
}
```

## 编译器信息

项目使用Android NDK r27d版本中的clang编译器：

- 编译器路径：`android-ndk-r27d-windows\android-ndk-r27d\toolchains\llvm\prebuilt\windows-x86_64\bin\aarch64-linux-android21-clang.cmd`
- 目标架构：ARM64 (aarch64)
- Android API级别：21

## GitHub上传说明

该项目已经配置好.gitignore文件，可以安全地上传到GitHub。以下目录和文件被忽略：

- `android-ndk-r27d-windows/` - Android NDK目录（体积较大）
- `LLVM/` - LLVM工具链目录（体积较大）
- `adb/` - ADB工具目录
- `*.exe` - 编译生成的可执行文件
- `.vscode/` - VS Code配置目录
- `.trae/` - Trae AI配置目录

上传到GitHub的项目将只包含源代码、构建脚本和文档，不包含大型二进制文件和敏感配置。