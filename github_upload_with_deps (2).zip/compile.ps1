# 简单的PowerShell编译脚本
Set-Location "F:\github ai"
& "F:\github ai\android-ndk-r27d-windows\android-ndk-r27d\toolchains\llvm\prebuilt\windows-x86_64\bin\aarch64-linux-android21-clang.cmd" -o hello.exe hello.c